package com.curtislewis.project1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toolbar;
import android.widget.CalendarView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);

        CalendarView cv = (CalendarView) findViewById(R.id.calendarView);
        final TextView textView = (TextView) findViewById(R.id.textDate);

        cv.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                String date = ""+month+"/"+day+"/"+year;
                textView.setText(date);

            }
        });
    }








}
